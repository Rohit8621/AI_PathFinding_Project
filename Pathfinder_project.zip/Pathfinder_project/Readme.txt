# Pathfinder Project

This project implements a simple pathfinding algorithm using the A* algorithm in Python with the help of the Pygame library. The project includes a Roomba sprite that follows the generated path on a grid-based map.

## Getting Started

### Prerequisites

- Python 3.x
- Pygame library

### Installation

1.Install Pygame:
pip install pygame

2.Running the Application
Navigate to the project directory:
  cd pathfinder-project

3.Run the main script:
python3 pathfinder_roomba.py

Use the mouse to create a path for the Roomba on the displayed grid.

4.Project Structure:
main.py: The main script to run the application.
pathfinding/: The core pathfinding logic.
images/: Contains the images used for the Roomba and selection.
maps/: Contains the map image used as the background.

5.Usage
Click on the grid cells to set the Roomba's path.
The Roomba will follow the generated path.